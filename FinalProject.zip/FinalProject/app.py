from flask import Flask, render_template, url_for, request
import pickle
import pandas as pd

app = Flask(__name__)
model = pickle.load(open('classification_model.pkl', 'rb'))
# Add routes here

@app.route('/')
def dashboard():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        one = (request.form['param1'])
        two= pd.to_numeric(request.form['param2'])
        three=pd.to_numeric(request.form['param3'])
        four= pd.to_numeric(request.form['param4'])
        five= pd.to_numeric(request.form['param5'])
        six= pd.to_numeric(request.form['param6'])
        sev= pd.to_numeric(request.form['param7'])
        och=pd.to_numeric(request.form['param8'])
        nuev=pd.to_numeric(request.form['param9'])
        diez=pd.to_numeric(request.form['param10'])
        once=pd.to_numeric(request.form['param11'])
        doce=pd.to_numeric(request.form['param12'])
        trece=pd.to_numeric(request.form['param13'])
        catorce=pd.to_numeric(request.form['param14'])
        quince=pd.to_numeric(request.form['param15'])
        dseis=pd.to_numeric(request.form['param16'])
        dsiete=pd.to_numeric(request.form['param17'])
        docho=pd.to_numeric(request.form['param18'])
        dnueve=pd.to_numeric(request.form['param19'])
        veinte=pd.to_numeric(request.form['param20'])
        vuno=pd.to_numeric(request.form['param21'])
        vdos=pd.to_numeric(request.form['param22'])
        vtres=pd.to_numeric(request.form['param23'])
        prediction = model.predict([[one,two,three,four,five,six,sev,och,nuev,diez,once,doce,trece,catorce,quince,dseis,dsiete,docho,dnueve,veinte,vuno,vdos,vtres]])
        if (prediction==1):
            text='The person will be probably late next month.'
        else:
            text='The person will not be late next month.'
        
        return render_template('index.html', prediction = text)

if __name__=="__main__":
    app.run(port=8087,debug=True)

